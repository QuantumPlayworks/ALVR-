use crate::{BuildPlatform, command};
use alvr_filesystem as afs;
use std::{fs, path::Path};
use xshell::{Shell, cmd};

pub enum OpenXRLoadersSelection {
    OnlyGeneric,
    OnlyPico,
    All,
}

pub fn choco_install(sh: &Shell, packages: &[&str]) -> Result<(), xshell::Error> {
    cmd!(
        sh,
        "powershell Start-Process choco -ArgumentList \"install {packages...} -y\" -Verb runAs -Wait"
    )
    .run()
}

pub fn prepare_x264_windows(deps_path: &Path) {
    let sh = Shell::new().unwrap();

    const VERSION: &str = "0.164";
    const REVISION: usize = 3086;

    let destination = deps_path.join("x264");

    command::download_and_extract_zip(
        &format!(
            "{}/{VERSION}.r{REVISION}/libx264_{VERSION}.r{REVISION}_msvc16.zip",
            "https://github.com/ShiftMediaProject/x264/releases/download",
        ),
        &destination,
    )
    .unwrap();

    fs::write(
        afs::deps_dir().join("x264.pc"),
        format!(
            r#"
prefix={}
exec_prefix=${{prefix}}/bin/x64
libdir=${{prefix}}/lib/x64
includedir=${{prefix}}/include

Name: x264
Description: x264 library
Version: {VERSION}
Libs: -L${{libdir}} -lx264
Cflags: -I${{includedir}}
"#,
            destination.to_string_lossy().replace('\\', "/")
        ),
    )
    .unwrap();

    cmd!(sh, "setx PKG_CONFIG_PATH {deps_path}").run().unwrap();
}

pub fn prepare_ffmpeg_windows(deps_path: &Path) {
    command::download_and_extract_zip(
        &format!(
            "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/{}",
            "ffmpeg-n7.1-latest-win64-gpl-shared-7.1.zip"
        ),
        deps_path,
    )
    .unwrap();

    fs::rename(
        deps_path.join("ffmpeg-n7.1-latest-win64-gpl-shared-7.1"),
        deps_path.join("ffmpeg"),
    )
    .unwrap();
}

fn prepare_libvpl_windows(deps_path: &Path) {
    let sh = Shell::new().unwrap();

    const VERSION: &str = "2.15.0";

    command::download_and_extract_zip(
        &format!("https://github.com/intel/libvpl/archive/refs/tags/v{VERSION}.zip"),
        deps_path,
    )
    .unwrap();

    let final_path = deps_path.join("libvpl");

    fs::rename(deps_path.join(format!("libvpl-{VERSION}")), &final_path).unwrap();

    let install_prefix = final_path.join("alvr_build");
    let _push_guard = sh.push_dir(final_path);

    cmd!(
        sh,
        "cmake -B build -DUSE_MSVC_STATIC_RUNTIME=ON -DCMAKE_INSTALL_PREFIX={install_prefix}"
    )
    .run()
    .unwrap();
    cmd!(sh, "cmake --build build --config Release")
        .run()
        .unwrap();
    cmd!(sh, "cmake --install build --config Release")
        .run()
        .unwrap();
}

pub fn prepare_windows_deps(skip_admin_priv: bool) {
    let sh = Shell::new().unwrap();

    let deps_path = afs::deps_dir().join("windows");
    sh.remove_path(&deps_path).ok();
    sh.create_dir(&deps_path).unwrap();

    if !skip_admin_priv {
        choco_install(
            &sh,
            &[
                "zip",
                "unzip",
                "llvm",
                "vulkan-sdk",
                "pkgconfiglite",
                "cmake",
            ],
        )
        .unwrap();
    }

    prepare_x264_windows(&deps_path);
    prepare_ffmpeg_windows(&deps_path);
    prepare_libvpl_windows(&deps_path);
}

pub fn prepare_linux_deps(enable_nvenc: bool) {
    let sh = Shell::new().unwrap();

    let deps_path = afs::deps_dir().join("linux");
    sh.remove_path(&deps_path).ok();
    sh.create_dir(&deps_path).unwrap();

    build_x264_linux(&deps_path);
    build_ffmpeg_linux(enable_nvenc, &deps_path);
}

pub fn build_x264_linux(deps_path: &Path) {
    let sh = Shell::new().unwrap();

    // x264 0.164
    command::download_and_extract_tar(
        "https://code.videolan.org/videolan/x264/-/archive/c196240409e4d7c01b47448d93b1f9683aaa7cf7/x264-c196240409e4d7c01b47448d93b1f9683aaa7cf7.tar.bz2",
        deps_path,
    )
    .unwrap();

    let final_path = deps_path.join("x264");

    fs::rename(
        deps_path.join("x264-c196240409e4d7c01b47448d93b1f9683aaa7cf7"),
        &final_path,
    )
    .unwrap();

    let flags = ["--enable-static", "--disable-cli", "--enable-pic"];

    let install_prefix = format!("--prefix={}", final_path.join("alvr_build").display());

    let _push_guard = sh.push_dir(final_path);

    cmd!(sh, "./configure {install_prefix} {flags...}")
        .run()
        .unwrap();

    let nproc = cmd!(sh, "nproc").read().unwrap();
    cmd!(sh, "make -j{nproc}").run().unwrap();
    cmd!(sh, "make install").run().unwrap();
}

pub fn build_ffmpeg_linux(enable_nvenc: bool, deps_path: &Path) {
    let sh = Shell::new().unwrap();

    command::download_and_extract_zip(
        "https://codeload.github.com/FFmpeg/FFmpeg/zip/n6.0",
        deps_path,
    )
    .unwrap();

    let final_path = deps_path.join("ffmpeg");

    fs::rename(deps_path.join("FFmpeg-n6.0"), &final_path).unwrap();

    let flags = [
        "--enable-gpl",
        "--enable-version3",
        "--enable-static",
        "--disable-programs",
        "--disable-doc",
        "--disable-avdevice",
        "--disable-avformat",
        "--disable-swresample",
        "--disable-swscale",
        "--disable-postproc",
        "--disable-network",
        "--disable-everything",
        "--enable-encoder=h264_vaapi",
        "--enable-encoder=hevc_vaapi",
        "--enable-encoder=av1_vaapi",
        "--enable-hwaccel=h264_vaapi",
        "--enable-hwaccel=hevc_vaapi",
        "--enable-hwaccel=av1_vaapi",
        "--enable-filter=scale_vaapi",
        "--enable-vulkan",
        "--enable-libdrm",
        "--enable-pic",
        "--enable-rpath",
        "--fatal-warnings",
    ];
    let install_prefix = format!("--prefix={}", final_path.join("alvr_build").display());
    // The reason for 4x$ in LDSOFLAGS var refer to https://stackoverflow.com/a/71429999
    // all varients of --extra-ldsoflags='-Wl,-rpath,$ORIGIN' do not work! don't waste your time trying!
    //
    let config_vars = r#"-Wl,-rpath,'$$$$ORIGIN'"#;

    let _push_guard = sh.push_dir(final_path);
    let _env_vars = sh.push_env("LDSOFLAGS", config_vars);

    // Patches ffmpeg for workarounds and patches that have yet to be unstreamed
    let ffmpeg_command = "for p in ../../../alvr/xtask/patches/*; do patch -p1 < $p; done";
    cmd!(sh, "bash -c {ffmpeg_command}").run().unwrap();

    if enable_nvenc {
        #[cfg(target_os = "linux")]
        {
            let codec_header_version = "12.1.14.0";
            let temp_download_dir = deps_path.join("dl_temp");
            command::download_and_extract_zip(
                &format!("https://github.com/FFmpeg/nv-codec-headers/archive/refs/tags/n{codec_header_version}.zip"),
                &temp_download_dir
            )
            .unwrap();

            let header_dir = deps_path.join("nv-codec-headers");
            let header_build_dir = header_dir.join("build");
            fs::rename(
                temp_download_dir.join(format!("nv-codec-headers-n{codec_header_version}")),
                &header_dir,
            )
            .unwrap();
            fs::remove_dir_all(temp_download_dir).unwrap();
            {
                let make_header_cmd =
                    format!("make install PREFIX='{}'", header_build_dir.display());
                let _header_push_guard = sh.push_dir(&header_dir);
                cmd!(sh, "bash -c {make_header_cmd}").run().unwrap();
            }

            let nvenc_flags = &[
                "--enable-encoder=h264_nvenc",
                "--enable-encoder=hevc_nvenc",
                "--enable-encoder=av1_nvenc",
            ];

            let env_vars = format!(
                "PKG_CONFIG_PATH='{}'",
                header_build_dir.join("lib/pkgconfig").display()
            );
            let flags_combined = flags.join(" ");
            let nvenc_flags_combined = nvenc_flags.join(" ");

            let command = format!(
                "{env_vars} ./configure {install_prefix} {flags_combined} {nvenc_flags_combined}"
            );

            cmd!(sh, "bash -c {command}").run().unwrap();
        }
    } else {
        cmd!(sh, "./configure {install_prefix} {flags...}")
            .run()
            .unwrap();
    }

    let nproc = cmd!(sh, "nproc").read().unwrap();
    cmd!(sh, "make -j{nproc}").run().unwrap();
    cmd!(sh, "make install").run().unwrap();
}

pub fn prepare_macos_deps() {}

pub fn prepare_server_deps(
    platform: Option<BuildPlatform>,
    skip_admin_priv: bool,
    enable_nvenc: bool,
) {
    match platform {
        Some(BuildPlatform::Windows) => prepare_windows_deps(skip_admin_priv),
        Some(BuildPlatform::Linux) => prepare_linux_deps(enable_nvenc),
        Some(BuildPlatform::Macos) => prepare_macos_deps(),
        Some(BuildPlatform::Android) => panic!("Android is not supported"),
        None => {
            if cfg!(windows) {
                prepare_windows_deps(skip_admin_priv);
            } else if cfg!(target_os = "linux") {
                prepare_linux_deps(enable_nvenc);
            } else if cfg!(target_os = "macos") {
                prepare_macos_deps();
            } else {
                panic!("Unsupported platform");
            }
        }
    }
}

fn get_android_openxr_loaders(selection: OpenXRLoadersSelection) {
    fn get_openxr_loader(name: &str, url: &str, source_dir: &str) {
        let sh = Shell::new().unwrap();
        let temp_dir = afs::build_dir().join("temp_download");
        sh.remove_path(&temp_dir).ok();
        sh.create_dir(&temp_dir).unwrap();
        let destination_dir = afs::deps_dir().join("android_openxr/arm64-v8a");
        fs::create_dir_all(&destination_dir).unwrap();

        command::download_and_extract_zip(url, &temp_dir).unwrap();
        fs::copy(
            temp_dir.join(source_dir).join("libopenxr_loader.so"),
            destination_dir.join(format!("libopenxr_loader{name}.so")),
        )
        .unwrap();
        fs::remove_dir_all(&temp_dir).ok();
    }

    const OPENXR_VERSION: &str = "1.1.36";
    get_openxr_loader(
        "",
        &format!(
            "https://github.com/KhronosGroup/OpenXR-SDK-Source/releases/download/\
            release-{OPENXR_VERSION}/openxr_loader_for_android-{OPENXR_VERSION}.aar",
        ),
        "prefab/modules/openxr_loader/libs/android.arm64-v8a",
    );

    if matches!(selection, OpenXRLoadersSelection::OnlyGeneric) {
        return;
    }

    get_openxr_loader(
        "_pico_old",
        "https://sdk.picovr.com/developer-platform/sdk/PICO_OpenXR_SDK_220.zip",
        "libs/android.arm64-v8a",
    );

    if matches!(selection, OpenXRLoadersSelection::OnlyPico) {
        return;
    }

    get_openxr_loader(
        "_quest1",
        "https://securecdn.oculus.com/binaries/download/?id=7577210995650755", // Version 64
        "OpenXR/Libs/Android/arm64-v8a/Release",
    );

    get_openxr_loader(
        "_yvr",
        "https://developer.yvrdream.com/yvrdoc/sdk/openxr/yvr_openxr_mobile_sdk_2.0.0.zip",
        "yvr_openxr_mobile_sdk_2.0.0/OpenXR/Libs/Android/arm64-v8a",
    );
}

pub fn build_android_deps(
    skip_admin_priv: bool,
    all_targets: bool,
    openxr_loaders_selection: OpenXRLoadersSelection,
) {
    let sh = Shell::new().unwrap();

    if cfg!(windows) && !skip_admin_priv {
        choco_install(&sh, &["unzip", "llvm"]).unwrap();
    }

    cmd!(sh, "rustup target add aarch64-linux-android")
        .run()
        .unwrap();
    if all_targets {
        cmd!(sh, "rustup target add armv7-linux-androideabi")
            .run()
            .unwrap();
        cmd!(sh, "rustup target add x86_64-linux-android")
            .run()
            .unwrap();
        cmd!(sh, "rustup target add i686-linux-android")
            .run()
            .unwrap();
    }
    cmd!(sh, "cargo install cbindgen").run().unwrap();
    cmd!(sh, "cargo install cargo-ndk --version 3.5.4")
        .run()
        .unwrap();
    cmd!(
        sh,
        "cargo install --git https://github.com/zarik5/cargo-apk cargo-apk"
    )
    .run()
    .unwrap();

    get_android_openxr_loaders(openxr_loaders_selection);
}
