use crate::theme;
use egui::{self, Response, Sense, StrokeKind, Ui, WidgetInfo, WidgetType};

pub fn switch(ui: &mut Ui, on: &mut bool) -> Response {
    let desired_size = theme::SWITCH_DOT_DIAMETER * egui::vec2(2.0, 1.0);
    let (rect, mut response) = ui.allocate_exact_size(desired_size, Sense::click());
    if response.clicked() {
        *on = !*on;
        response.mark_changed();
    }
    response.widget_info(|| WidgetInfo::selected(WidgetType::Checkbox, true, *on, ""));

    let how_on = ui.ctx().animate_bool(response.id, *on);
    let visuals = ui.style().interact_selectable(&response, *on);
    let rect = rect.expand(visuals.expansion);
    let radius = 0.5 * rect.height();
    ui.painter().rect(
        rect,
        radius,
        visuals.bg_fill,
        visuals.bg_stroke,
        StrokeKind::Middle,
    );
    let circle_x = egui::lerp((rect.left() + radius)..=(rect.right() - radius), how_on);
    let center = egui::pos2(circle_x, rect.center().y);
    ui.painter()
        .circle(center, 0.75 * radius, visuals.bg_fill, visuals.fg_stroke);

    response
}
