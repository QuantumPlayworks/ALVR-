use alvr_common::anyhow::{Result, bail};
use cpal::{Device, platform::DeviceInner};
use rodio::DeviceTrait;
use windows::{
    Win32::{
        Devices::FunctionDiscovery::PKEY_Device_FriendlyName,
        Media::Audio::{
            DEVICE_STATE_ACTIVE, Endpoints::IAudioEndpointVolume, IMMDevice, IMMDeviceEnumerator,
            MMDeviceEnumerator, eCapture, eRender,
        },
        System::Com::{self, CLSCTX_ALL, COINIT_MULTITHREADED, STGM_READ},
    },
    core::GUID,
};

fn get_windows_device(device: &Device) -> Result<IMMDevice> {
    let device_name = device.name()?;

    unsafe {
        // This will fail the second time is called, ignore the error
        Com::CoInitializeEx(None, COINIT_MULTITHREADED).ok().ok();

        let imm_device_enumerator: IMMDeviceEnumerator =
            Com::CoCreateInstance(&MMDeviceEnumerator, None, CLSCTX_ALL)?;

        let direction = if device.supports_output() {
            eRender
        } else {
            eCapture
        };
        let imm_device_collection =
            imm_device_enumerator.EnumAudioEndpoints(direction, DEVICE_STATE_ACTIVE)?;

        for i in 0..imm_device_collection.GetCount()? {
            let imm_device = imm_device_collection.Item(i)?;

            let imm_device_name = imm_device
                .OpenPropertyStore(STGM_READ)?
                .GetValue(&PKEY_Device_FriendlyName)?
                .to_string();

            if imm_device_name == device_name {
                return Ok(imm_device);
            }
        }

        bail!("No device found with specified name")
    }
}

pub fn get_windows_device_id(device: &Device) -> Result<String> {
    unsafe {
        let imm_device = get_windows_device(device)?;

        let id_str_ptr = imm_device.GetId()?;
        let id_str = id_str_ptr.to_string()?;
        Com::CoTaskMemFree(Some(id_str_ptr.0 as _));

        Ok(id_str)
    }
}

// device must be an output device
pub fn set_mute_windows_device(device: &Device, mute: bool) -> Result<()> {
    unsafe {
        let imm_device = get_windows_device(device)?;

        let endpoint_volume = imm_device.Activate::<IAudioEndpointVolume>(CLSCTX_ALL, None)?;

        endpoint_volume.SetMute(mute, &GUID::zeroed())?;
    }

    Ok(())
}

pub fn is_same_device(device1: &Device, device2: &Device) -> bool {
    let DeviceInner::Wasapi(dev1) = device1.as_inner();
    let DeviceInner::Wasapi(dev2) = device2.as_inner();

    dev1 == dev2
}
